 <link href="<?php echo get_template_directory_uri(); ?>/assets/js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/assets/js/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/assets/js/owl-carousel/owl.transitions.css" rel="stylesheet">